<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>
    <?php echo get_the_title(); ?> | <?php bloginfo('name'); ?>
  </title>
  <?php wp_head(); ?>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <?php
  $primary_color = get_theme_mod('primary_color_setting', '#487cb9');
  $secondary_color = get_theme_mod('secondary_color_setting', '#f1f6fc');
  $text_color = get_theme_mod('text_color_setting', '#2c2c2c');
  $white_color = get_theme_mod('white_background_color_setting', '#fff');
  ?>
  <style>
    :root {
      --primary:
        <?php echo esc_attr($primary_color); ?>
      ;
      --secondary:
        <?php echo esc_attr($secondary_color); ?>
      ;
      --text:
        <?php echo esc_attr($text_color); ?>
      ;
      --white:
        <?php echo esc_attr($white_color); ?>
      ;
    }
  </style>
  <?php
  $body_background_color = get_theme_mod('body_background_color_setting', '#ffffff');
  ?>
  <style>
    body {
      background-color:
        <?php echo esc_attr($body_background_color); ?>
      ;
    }
  </style>
</head>

<body <?php body_class(); ?>>
  <?php wp_body_open(); ?>
  <div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'alika'); ?></a>
    <section id="site-header">
      <header class="container">
        <nav class="row">
          <div class="col-lg-3 col-md-4 col-sm-8 header-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
              <?php if (has_custom_logo()): ?>
                <?php the_custom_logo(); ?>
              <?php else: ?>
                <?php if (is_front_page() && is_home()): ?>
                  <h1 class="site-title"><?php bloginfo('name'); ?></h1>
                <?php else: ?>
                  <p class="site-title"><?php bloginfo('name'); ?></p>
                <?php endif; ?>
              <?php endif; ?>
            </a>
          </div>
          <div class="col-lg-5 col-md-4 col-sm-12 header-menu">
            <?php
            wp_nav_menu(
              array(
                'theme_location' => 'menu-1'
              )
            )
              ?>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12 header-btn">
            <div class="navbtn">
              <?php
              $button_text = get_theme_mod('button_text_setting', 'Download CV');
              $button_link = get_theme_mod('button_link_setting', '#');
              echo '<a href="' . esc_url($button_link) . '">' . esc_html($button_text) . '</a>';
              ?>
            </div>
            <div class="nav-scoial">
              <ul>
                <?php
                $fb_url = get_theme_mod('fb_url_setting', '#');
                $instagram_url = get_theme_mod('instagram_url_setting', '#');
                $linkedin_url = get_theme_mod('linkedin_url_setting', '#');
                $twitter_url = get_theme_mod('twitter_url_setting', '#');
                ?>
                <a href="<?php echo esc_url($fb_url); ?>" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="<?php echo esc_url($instagram_url); ?>" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="<?php echo esc_url($twitter_url); ?>" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="<?php echo esc_url($linkedin_url); ?>" class="linkedin"><i class="bi bi-linkedin"></i></a>

              </ul>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-8 mobile-menu">
              <i class="bi bi-list mobile-nav-toggle"></i>
            </div>
          </div>
        </nav>
      </header>
    </section>
    <section id="mobile-header">
      <div class="container mobile-header">
        <div class="header-logo">
          <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
            <?php if (has_custom_logo()): ?>
              <?php the_custom_logo(); ?>
            <?php else: ?>
              <?php if (is_front_page() && is_home()): ?>
                <h1 class="site-title"><?php bloginfo('name'); ?></h1>
              <?php else: ?>
                <p class="site-title"><?php bloginfo('name'); ?></p>
              <?php endif; ?>
            <?php endif; ?>
          </a>
        </div>
        <div class="header-menu">
          <div class="container">
            <div class="mobile-menu">
              <?php
              wp_nav_menu(
                array(
                  'theme_location' => 'menu-1'
                )
              )
                ?>
            </div>
          </div>
          <div class="header-btn container">
            <div class="navbtn">
              <?php
              $button_text = get_theme_mod('button_text_setting', 'Download CV');
              $button_link = get_theme_mod('button_link_setting', '#');
              echo '<a href="' . esc_url($button_link) . '">' . esc_html($button_text) . '</a>';
              ?>
            </div>
            <div class="nav-scoial">
              <ul>
                <?php
                $fb_url = get_theme_mod('fb_url_setting', '#');
                $instagram_url = get_theme_mod('instagram_url_setting', '#');
                $linkedin_url = get_theme_mod('linkedin_url_setting', '#');
                $twitter_url = get_theme_mod('twitter_url_setting', '#');
                ?>
                <a href="<?php echo esc_url($fb_url); ?>" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="<?php echo esc_url($instagram_url); ?>" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="<?php echo esc_url($twitter_url); ?>" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="<?php echo esc_url($linkedin_url); ?>" class="linkedin"><i class="bi bi-linkedin"></i></a>

              </ul>
            </div>
          </div>
        </div>
        <div class="mobile-menu">
          <i class="fa-solid fa-bars mobile-nav-toggle"></i>
          <i class="fa-regular fa-circle-xmark mobile-nav-toggle"></i>
        </div>
      </div>
    </section>