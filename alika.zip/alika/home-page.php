<?php
/*
Template Name: Theme Default Home
*/
get_header();
?>
<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">
  <div class="container">
    <div class="row">
      <div class="col-lg-7 col-md-6 col-sm-12 hero-left">
        <?php
        $top_heading = get_field('hero_section')['first_heading'];

        if (!empty($top_heading)) {
          echo "<h2>" . esc_html($top_heading) . "</h2>";
        } else {
          echo "<h2>Hello, I am</h2>";
        }
        ?>
        <?php
        $second_heading = get_field('hero_section')['second_heading'];

        if (!empty($second_heading)) {
          echo "<h1>" . esc_html($second_heading) . "</h1>";
        } else {
          echo "<h1>Mr. John Deo</h1>";
        }
        ?>
        <div class="typing">
          <p>A <span class="typed-text"></span><span class="cursor">&nbsp;</span></p>
          <script>
            const typedTextSpan = document.querySelector(".typed-text");
            const cursorSpan = document.querySelector(".cursor");
            const typingSkills = [
              "<?php echo get_field('hero_section')['first_typing_skill']; ?>",
              "<?php echo get_field('hero_section')['second_typing_skill']; ?>",
              "<?php echo get_field('hero_section')['third_typing_skill']; ?>"
            ];
            const typingDelay = 100;
            const erasingDelay = 100;
            const newTextDelay = 2000;
            let textArrayIndex = 0;
            let charIndex = 0;
            function type() {
              if (charIndex < typingSkills[textArrayIndex].length) {
                if (!cursorSpan.classList.contains("typing")) {
                  cursorSpan.classList.add("typing");
                }
                typedTextSpan.textContent += typingSkills[textArrayIndex].charAt(charIndex);
                charIndex++;
                setTimeout(type, typingDelay);
              } else {
                cursorSpan.classList.remove("typing");
                setTimeout(erase, newTextDelay);
              }
            }
            function erase() {
              if (charIndex > 0) {
                if (!cursorSpan.classList.contains("typing")) {
                  cursorSpan.classList.add("typing");
                }
                typedTextSpan.textContent = typingSkills[textArrayIndex].substring(0, charIndex - 1);
                charIndex--;
                setTimeout(erase, erasingDelay);
              } else {
                cursorSpan.classList.remove("typing");
                textArrayIndex++;
                if (textArrayIndex >= typingSkills.length) {
                  textArrayIndex = 0;
                }
                setTimeout(type, typingDelay + 1100);
              }
            }
            document.addEventListener("DOMContentLoaded", function () {
              if (typingSkills.length) {
                setTimeout(type, newTextDelay);
              }
            });
          </script>
        </div>
        <div class="hero-left-btn" data-aos="fade-up" data-aos-delay="500">
          <?php
          $first_button_text = get_field('hero_section')['first_button_text'];
          $first_button_link = get_field('hero_section')['first_button_link'];
          if ($first_button_text && $first_button_link) {
            echo '<a href="' . esc_url($first_button_link['url']) . '">' . esc_html($first_button_text) . '</a>';
          } else {
            echo '<a href="#">Download CV</a>';
          }
          ?>
          <?php
          $second_button_text = get_field('hero_section')['second_button_text'];
          $second_button_link = get_field('hero_section')['second_button_link'];
          if ($second_button_text && $second_button_link) {
            echo '<a href="' . esc_url($second_button_link['url']) . '">' . esc_html($second_button_text) . '</a>';
          } else {
            echo '<a href="#">Hire Me</a>';
          }
          ?>
        </div>
      </div>
      <div class="col-lg-5 col-md-6 col-sm-12 hero-right">
        <div class="owl-carousel">
          <?php
          $hero_images = get_field('hero_section_images');
          if ($hero_images && is_array($hero_images) && !empty($hero_images)) {
            $first_hero_image_url = isset($hero_images['first_hero_image']['url']) ? esc_url($hero_images['first_hero_image']['url']) : '';
            $second_hero_image_url = isset($hero_images['second_hero_image']['url']) ? esc_url($hero_images['second_hero_image']['url']) : '';
            $third_hero_image_url = isset($hero_images['third_hero_image']['url']) ? esc_url($hero_images['third_hero_image']['url']) : '';

            if (!empty($first_hero_image_url)) {
              echo '<div class="item"> <img src="' . $first_hero_image_url . '" alt=""></div>';
            }
            if (!empty($second_hero_image_url)) {
              echo '<div class="item"> <img src="' . $second_hero_image_url . '" alt=""></div>';
            }
            if (!empty($third_hero_image_url)) {
              echo '<div class="item"> <img src="' . $third_hero_image_url . '" alt=""></div>';
            }
          } else {
            $default_image_url = get_template_directory_uri() . '/assets/img/hero.png';
            echo '<div class="item"> <img src="' . $default_image_url . '" alt=""></div>';
            echo '<div class="item"> <img src="' . $default_image_url . '" alt=""></div>';
            echo '<div class="item"> <img src="' . $default_image_url . '" alt=""></div>';
          }
          ?>
        </div>
      </div>
    </div>
</section><!-- End Hero -->
<main id="main">
  <!-- ======= About Section ======= -->
  <section id="about" data-aos="fade-up">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-md-5 col-sm-12 about-left">
          <?php
          $about_section = get_field('about_section');
          $about_image_url = isset($about_section['about_image']['url']) ? esc_url($about_section['about_image']['url']) : '';
          $about_image_alt = isset($about_section['about_image']['alt']) ? esc_attr($about_section['about_image']['alt']) : '';
          if (!empty($about_image_url)) {
            echo '<img src="' . $about_image_url . '" alt="' . $about_image_alt . '">';
          } else {
            $default_image_url = get_template_directory_uri() . '/assets/img/about.png';
            echo '<img src="' . $default_image_url . '" alt="Default About Image">';
          }
          ?>
        </div>
        <div class="col-lg-7 col-md-7 col-sm-12 about-right">
          <?php
          $about_section = get_field('about_section');
          $first_heading = isset($about_section['first_heading']) ? esc_html($about_section['first_heading']) : '';
          if (!empty($first_heading)) {
            echo '<h2>' . $first_heading . '</h2>';
          } else {
            echo '<h2>About Me</h2>';
          }
          ?>
          <div class="typing">
            <p>A <span class="typed-text"></span><span class="cursor">&nbsp;</span></p>
            <script>
              document.addEventListener("DOMContentLoaded", function () {
                const typedTextSpan = document.querySelector(
                  "#about .about-right .typing .typed-text"
                );
                const cursorSpan = document.querySelector(
                  "#about .about-right .typing .cursor"
                );
                const typingSkills = [
                  "<?php echo get_field('hero_section')['first_typing_skill']; ?>",
                  "<?php echo get_field('hero_section')['second_typing_skill']; ?>",
                  "<?php echo get_field('hero_section')['third_typing_skill']; ?>"
                ];
                const typingDelay = 100;
                const erasingDelay = 100;
                const newTextDelay = 2000;
                let textArrayIndex = 0;
                let charIndex = 0;
                function type() {
                  if (charIndex < typingSkills[textArrayIndex].length) {
                    if (!cursorSpan.classList.contains("typing")) {
                      cursorSpan.classList.add("typing");
                    }
                    typedTextSpan.textContent += typingSkills[textArrayIndex].charAt(charIndex);
                    charIndex++;
                    setTimeout(type, typingDelay);
                  } else {
                    cursorSpan.classList.remove("typing");
                    setTimeout(erase, newTextDelay);
                  }
                }
                function erase() {
                  if (charIndex > 0) {
                    if (!cursorSpan.classList.contains("typing")) {
                      cursorSpan.classList.add("typing");
                    }
                    typedTextSpan.textContent = typingSkills[textArrayIndex].substring(0, charIndex - 1);
                    charIndex--;
                    setTimeout(erase, erasingDelay);
                  } else {
                    cursorSpan.classList.remove("typing");
                    textArrayIndex++;
                    if (textArrayIndex >= typingSkills.length) {
                      textArrayIndex = 0;
                    }
                    setTimeout(type, typingDelay + 1100);
                  }
                }
                function changeText() {
                  charIndex = 0;
                  textArrayIndex++;
                  if (textArrayIndex >= typingSkills.length) {
                    textArrayIndex = 0;
                  }
                  setTimeout(type, typingDelay);
                }
                setTimeout(changeText, 3000);
              });
            </script>
          </div>
          <?php
          $about_section = get_field('about_section');
          $about_me = isset($about_section['about_me']) ? $about_section['about_me'] : '';
          if (!empty($about_me)) {
            echo '<h6>' . $about_me . '</h6>';
          } else {
            echo '<h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</h6>';
          }
          ?>
          <table>
            <tbody>
              <tr data-aos="fade-up">
                <?php
                $about_table = get_field('about_table');
                $first_info = isset($about_table['first_info']) ? esc_html($about_table['first_info']) : '';
                $first_info_details = isset($about_table['first_info_details']) ? esc_html($about_table['first_info_details']) : '';
                if (!empty($first_info) && !empty($first_info_details)) {
                  echo '<td><b>' . $first_info . '</b></td>';
                  echo '<td style="padding-left:30px;">' . $first_info_details . '</td>';
                } else {
                  echo '<td><b>Full Name:</b></td>';
                  echo '<td style="padding-left:30px;">John Deo</td>';
                }
                ?>
              </tr>
              <tr data-aos="fade-up">
                <?php
                $about_table = get_field('about_table');
                $second_info = isset($about_table['second_info']) ? esc_html($about_table['second_info']) : '';
                $second_info_details = isset($about_table['second_info_details']) ? esc_html($about_table['second_info_details']) : '';
                if (!empty($second_info) && !empty($second_info_details)) {
                  echo '<td><b>' . $second_info . '</b></td>';
                  echo '<td style="padding-left:30px;">' . $second_info_details . '</td>';
                } else {
                  echo '<td><b>Date of Birth:</b></td>';
                  echo '<td style="padding-left:30px;">Augest 7, 1998</td>';
                }
                ?>
              </tr>
              <tr data-aos="fade-up">
                <?php
                $about_table = get_field('about_table');
                $third_info = isset($about_table['third_info']) ? esc_html($about_table['third_info']) : '';
                $third_info_details = isset($about_table['third_info_details']) ? esc_html($about_table['third_info_details']) : '';
                if (!empty($third_info) && !empty($third_info_details)) {
                  echo '<td><b>' . $third_info . '</b></td>';
                  echo '<td style="padding-left:30px;">' . $third_info_details . '</td>';
                } else {
                  echo '<td><b>Age:</b></td>';
                  echo '<td style="padding-left:30px;">25</td>';
                }
                ?>
              </tr>
              <tr data-aos="fade-up">
                <?php
                $about_table = get_field('about_table');
                $fourth_info = isset($about_table['fourth_info']) ? esc_html($about_table['fourth_info']) : '';
                $fourth_info_details = isset($about_table['fourth_info_details']) ? esc_html($about_table['fourth_info_details']) : '';
                if (!empty($fourth_info) && !empty($fourth_info_details)) {
                  echo '<td><b>' . $fourth_info . '</b></td>';
                  echo '<td style="padding-left:30px;">' . $fourth_info_details . '</td>';
                } else {

                  echo '<td><b>Email:</b></td>';
                  echo '<td style="padding-left:30px;"> test@gmail.com</td>';
                }
                ?>
              </tr>
              <tr data-aos="fade-up">
                <?php
                $about_table = get_field('about_table');
                $fifth_info = isset($about_table['fifth_info']) ? esc_html($about_table['fifth_info']) : '';
                $fifth_info_details = isset($about_table['fifth_info_details']) ? esc_html($about_table['fifth_info_details']) : '';
                if (!empty($fifth_info) && !empty($fifth_info_details)) {
                  echo '<td><b>' . $fifth_info . '</b></td>';
                  echo '<td style="padding-left:22px;">' . $fifth_info_details . '</td>';
                } else {
                  echo '<td><b>Phone Number:</b></td>';
                  echo '<td style="padding-left:22px;">03028090100</td>';
                }
                ?>
              </tr>
              <tr data-aos="fade-up">
                <?php
                $about_table = get_field('about_table');
                $address = isset($about_table['address']) ? esc_html($about_table['address']) : '';
                if (!empty($address)) {
                  echo '<td><b>Address:</b></td>';
                  echo '<td style="padding-left:30px;">' . $address . '</td>';
                } else {
                  echo '<td><b>Address:</b></td>';
                  echo '<td style="padding-left:30px;">Maxico</td>';
                }
                ?>
              </tr>
            </tbody>
          </table>
          <div class="social" data-aos="fade-up">
            <a href="<?php echo esc_url($fb_url); ?>" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="<?php echo esc_url($instagram_url); ?>" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="<?php echo esc_url($twitter_url); ?>" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="<?php echo esc_url($linkedin_url); ?>" class="linkedin"><i class="bi bi-linkedin"></i></a>
          </div>
          <div class="about-left-btn" data-aos="fade-up">
            <?php
            $first_button_text = get_field('hero_section')['first_button_text'];
            $first_button_link = get_field('hero_section')['first_button_link'];
            if ($first_button_text && $first_button_link) {
              echo '<a href="' . esc_url($first_button_link['url']) . '">' . esc_html($first_button_text) . '</a>';
            } else {
              echo '<a href="#">Download CV</a>';
            }
            ?>
          </div>
        </div>
      </div>
    </div>
    </div>
  </section><!-- End About Section -->
  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
  <div class="container" data-aos="fade-up">
    <?php
    $portfolio_heading = get_field('portfolio')['heading'];
    if ($portfolio_heading) {
      echo '<h2 data-aos="fade-up">' . esc_html($portfolio_heading) . '</h2>';
    } else {
      echo '<h2 data-aos="fade-up">My Portfolio</h2>';
    }
    ?>
    <div class="row" data-aos="fade-up" data-aos-delay="100">
      <div class="col-lg-12 d-flex justify-content-center">
        <ul id="portfolio-flters">
          <li data-filter="*" class="filter-active">ALL</li>
          <?php
          $terms = get_terms(
            array(
              'taxonomy' => 'project-type',
              'hide_empty' => false,
              'suppress_filters' => false, // default: true
            )
          );

          foreach ($terms as $term) {
            ?>
            <li data-filter=".<?php echo $term->slug; ?>"><?php echo $term->name; ?></li>
            <?php
          }
          ?>
        </ul>
      </div>
    </div>
    <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
      <?php
      $args = array(
        'post_type' => 'project',
        'posts_per_page' => -1,
      );
      $query = new WP_Query($args);
      if ($query->have_posts()):
        $counter = 0;
        while ($query->have_posts()):
          $query->the_post();
          $terms = get_the_terms(get_the_ID(), 'project-type');
          $category_classes = array();
          if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
              $category_classes[] = $term->slug;
            }
          }
          $category_class = implode(' ', $category_classes);
          $project_title = get_field('project_title');
          $project_image = get_field('project_picture');
          $project_id = get_the_ID();
          $project_description = get_field('project_description');
          $project_url = get_field('project_url');
          $tech_stack_image = get_field('tech_stack_image');
          $review_from_customer = get_field('review_from_customer');
          $client_name = get_field('client_name');
          $post_term = get_the_terms($project_id, 'project-type');

          // Increment the counter
          $counter++;

          ?>
          <div class="col-lg-4 col-md-4 col-sm-12 portfolio-item <?php echo $post_term[0]->slug; ?>">
            <div class="project-item" data-aos="fade-up" data-filter="<?php echo $post_term[0]->slug; ?>">
              <img src="<?php echo esc_url($project_image['url']); ?>"
                   alt="<?php echo esc_attr($project_image['alt']); ?>">
              <div class="overlay">
                <h3 class="project-title"><?php echo esc_html($project_title); ?></h3>
                <a href="#popup-<?php echo $counter; ?>" class="popup-trigger"><i
                    class="fas fa-external-link-alt"></i></a>
              </div>
            </div>
          </div>

          <!-- Popup code inside the loop -->
          <div id="popup-<?php echo $counter; ?>" class="white-popup mfp-hide">
            <button title="Close (Esc)" type="button" class="mfp-close"><i class="bi bi-x-circle"></i></button>
            <h2> Project Description</h2>
            <?php echo '<p>' . wp_kses_post($project_description) . '</p>'; ?>
            <h2>Project URL</h2>
            <a href="<?php echo esc_url($project_url); ?>"><?php echo esc_url($project_url); ?></a>
            <h2>Tech Stack</h2>
            <img src="<?php echo get_template_directory_uri() ?>/assets/img/html.png" alt="" style="width:50px;">
            <h2>Review from Customer</h2>
            <?php echo '<p>' . wp_kses_post($review_from_customer) . '</p>'; ?>
            <h3><?php echo esc_html($client_name); ?></h3>
          </div>
          <!-- End Popup code inside the loop -->

        <?php endwhile;
        wp_reset_postdata(); ?>
      <?php else: ?>
        <p><?= __('No Portfolio Added', 'portfolio'); ?></p>
      <?php endif; ?>
    </div>
  </div>
  <div class="load" data-aos="zoom-in">
    <?php
    $load_button_text = get_field('portfolio')['load_button_text'];
    $load_button_link = get_field('portfolio')['load_button_link'];
    if ($load_button_text && $load_button_link) {
      echo '<a href="' . esc_url($load_button_link['url']) . '">' . esc_html($load_button_text) . '</a>';
    }
    ?>
  </div>
</section><!-- End Portfolio Section -->

  <!-- End Portfolio Section -->
  <!-- ======= Resume Section ======= -->
  <section id="resume">
    <div class="container">
      <div class="row">
        <?php
        $resume_heading = get_field('resume_section')['section_heading'];
        if ($resume_heading) {
          echo '<h2 data-aos="fade-up">' . esc_html($resume_heading) . '</h2>';
        } else {
          echo '<h2 data-aos="fade-up">Resume</h2>';
        }
        ?>
        <div class="data-tabs" data-aos="fade-up">
          <?php
          $first_top_heading = get_field('resume_section')['first_top_heading'];
          if ($first_top_heading) {
            echo '<a class="active-tab ex" data-tab="experience">' . esc_html($first_top_heading) . '</a>';
          } else {
            echo '<a class="active-tab ex" data-tab="experience">Experience</a>';
          }
          ?>
          <?php
          $section_heading = get_field('resume_section')['second_top_heading'];
          if ($section_heading) {
            echo '<a data-tab="education" class="ed">' . esc_html($section_heading) . '</a>';
          } else {
            echo '<a data-tab="education" class="ed">Education</a>';
          }
          ?>
          <?php
          $third_top_heading = get_field('resume_section')['third_top_heading'];
          if ($third_top_heading) {
            echo '<a data-tab="skills" class="sk">' . esc_html($third_top_heading) . '</a>';
          } else {
            echo '<a data-tab="skills" class="sk">Skills</a>';
          }
          ?>
        </div>
        <div class="data-details">
          <div class="experience-data">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 resume-left">
                  <div class="top-icon">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/img/linetop.png" alt="">
                  </div>
                  <?php
                  $first_experience_date = get_field('experience_group')['first_experience_date'];
                  if ($first_experience_date) {
                    echo '<h2 style="margin-top:80px;" data-aos="fade-up">' . esc_html($first_experience_date) . '</h2>';
                  } else {
                    echo '<h2 style="margin-top:80px;" data-aos="fade-up">2021-2022</h2>';
                  }
                  ?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 resume-right" data-aos="fade-up">
                  <?php
                  $first_experience_title = get_field('experience_group')['first_experience_title'];
                  if ($first_experience_title) {
                    echo '<h2>' . esc_html($first_experience_title) . '</h2>';
                  } else {
                    echo '<h2>Experience Title Here</h2>';
                  }
                  ?>
                  <?php
                  $first_experience_category = get_field('experience_group')['first_experience_category'];
                  if ($first_experience_category) {
                    echo '<h3>' . esc_html($first_experience_category) . '</h3>';
                  } else {
                    echo '<h3>Category</h3>';
                  }
                  ?>
                  <?php
                  $first_experience_details = get_field('experience_group')['first_experience_details'];
                  if ($first_experience_details) {
                    echo '<p>' . wp_kses_post($first_experience_details) . '</p>';
                  } else {
                    echo '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et is the quasi architecto beatae vitae dicta sunt explicabo.</p>';
                  }
                  ?>
                </div>
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 resume-left" data-aos="fade-up">
                  <?php
                  $second_experience_date = get_field('experience_group')['second_experience_date'];
                  if ($second_experience_date) {
                    echo '<h2 data-aos="fade-up">' . esc_html($second_experience_date) . '</h2>';
                  } else {
                    echo '<h2 data-aos="fade-up">2021-2022</h2>';
                  }
                  ?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 resume-right" data-aos="fade-up">
                  <?php
                  $second_experience_title = get_field('experience_group')['second_experience_title'];
                  if ($second_experience_title) {
                    echo '<h2>' . esc_html($second_experience_title) . '</h2>';
                  } else {
                    echo '<h2>Experience Title Here</h2>';
                  }
                  ?>
                  <?php
                  $second_experience_category = get_field('experience_group')['second_experience_category'];
                  if ($second_experience_category) {
                    echo '<h3>' . esc_html($second_experience_category) . '</h3>';
                  } else {
                    echo '<h3>Category</h3>';
                  }
                  ?>
                  <?php
                  $second_experience_details = get_field('experience_group')['second_experience_details'];
                  if ($second_experience_details) {
                    echo '<p>' . wp_kses_post($second_experience_details) . '</p>';
                  } else {
                    echo '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et is the quasi architecto beatae vitae dicta sunt explicabo.</p>';
                  }
                  ?>
                </div>
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 resume-left" data-aos="fade-up">
                  <?php
                  $third_experience_date = get_field('experience_group')['third_experience_date'];
                  if ($third_experience_date) {
                    echo '<h2>' . $third_experience_date . '</h2>';
                  } else {
                    echo '<h2>2021-2022</h2>';
                  }
                  ?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 resume-right" data-aos="fade-up">
                  <?php
                  $third_experience_title = get_field('experience_group')['third_experience_heading'];
                  if ($third_experience_title) {
                    echo '<h2>' . $third_experience_title . '</h2>';
                  } else {
                    echo '<h2>Experience Title Here</h2>';
                  }
                  ?>
                  <?php
                  $third_experience_category = get_field('experience_group')['third_experience_category'];
                  if ($third_experience_category) {
                    echo '<h3>' . $third_experience_category . '</h3>';
                  } else {
                    echo '<h3>Category</h3>';
                  }
                  ?>
                  <?php
                  $third_experience_details = get_field('experience_group')['third_experience_details'];
                  if ($third_experience_details) {
                    echo '<p>' . wp_kses_post($third_experience_details) . '</p>';
                  } else {
                    echo '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et is the quasi architecto beatae vitae dicta sunt explicabo.</p>';
                  }
                  ?>
                </div>
              </div>
            </div>
            <div class="line"></div>
            <div class="bottom-icon"></div>
          </div>
          <div class="education-data hidden experience-data">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 resume-left">
                  <div class="top-icon">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/img/linetop2.png" alt="">
                  </div>
                  <?php
                  $first_education_date = get_field('education_section')['first_education_date'];
                  if ($first_education_date) {
                    echo '<h2 style="margin-top:80px;" data-aos="fade-up">' . esc_html($first_education_date) . '</h2>';
                  } else {
                    echo '<h2 style="margin-top:80px;" data-aos="fade-up">2021-2022</h2>';
                  }
                  ?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 resume-right" data-aos="fade-up">
                  <?php
                  $first_education_title = get_field('education_section')['first_education_title'];
                  if ($first_education_title) {
                    echo '<h2>' . esc_html($first_education_title) . '</h2>';
                  } else {
                    echo '<h2>Education Title Here</h2>';
                  }
                  ?>
                  <?php
                  $first_education_category = get_field('education_section')['first_education_category'];
                  if ($first_education_category) {
                    echo '<h3>' . esc_html($first_education_category) . '</h3>';
                  } else {
                    echo '<h3>University of Study</h3>';
                  }
                  ?>
                  <?php
                  $first_education_details = get_field('education_section')['first_education_details'];
                  if ($first_education_details) {
                    echo '<p>' . wp_kses_post($first_education_details) . '</p>';
                  } else {
                    echo '<p>Education Details Here</p>';
                  }
                  ?>
                </div>
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 resume-left" data-aos="fade-up">
                  <?php
                  $second_education_date = get_field('education_section')['second_education_date'];
                  if ($second_education_date) {
                    echo '<h2 data-aos="fade-up">' . esc_html($second_education_date) . '</h2>';
                  } else {
                    echo '<h2 data-aos="fade-up">2021-2022</h2>';
                  }
                  ?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 resume-right" data-aos="fade-up">
                  <?php
                  $second_education_title = get_field('education_section')['second_education_title'];
                  if ($second_education_title) {
                    echo '<h2>' . esc_html($second_education_title) . '</h2>';
                  } else {
                    echo '<h2>Education Title Here</h2>';
                  }
                  ?>
                  <?php
                  $second_education_category = get_field('education_section')['second_education_category'];
                  if ($second_education_category) {
                    echo '<h3>' . esc_html($second_education_category) . '</h3>';
                  } else {
                    echo '<h3>University of Study</h3>';
                  }
                  ?>
                  <?php
                  $second_education_details = get_field('education_section')['second_education_details'];
                  if ($second_education_details) {
                    echo '<p>' . wp_kses_post($second_education_details) . '</p>';
                  } else {
                    echo '<p>Education Details Here</p>';
                  }
                  ?>
                </div>
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 resume-left" data-aos="fade-up">
                  <?php
                  $third_education_date = get_field('education_section')['third_education_date'];
                  if ($third_education_date) {
                    echo '<h2 data-aos="fade-up">' . esc_html($third_education_date) . '</h2>';
                  } else {
                    echo '<h2 data-aos="fade-up">2021-2022</h2>';
                  }
                  ?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-12 resume-right" data-aos="fade-up">
                  <?php
                  $third_education_title = get_field('education_section')['third_education_heading'];
                  if ($third_education_title) {
                    echo '<h2>' . esc_html($third_education_title) . '</h2>';
                  } else {
                    echo '<h2>Experience Title Here</h2>';
                  }
                  ?>
                  <?php
                  $third_education_category = get_field('education_section')['third_education_category'];
                  if ($third_education_category) {
                    echo '<h3>' . esc_html($third_education_category) . '</h3>';
                  } else {
                    echo '<h3>University of Study</h3>';
                  }
                  ?>
                  <?php
                  $third_education_details = get_field('education_section')['third_education_details'];
                  if ($third_education_details) {
                    echo '<p>' . wp_kses_post($third_education_details) . '</p>';
                  } else {
                    echo '<p>Education Details Here</p>';
                  }
                  ?>
                </div>
              </div>
            </div>
            <div class="line"></div>
            <div class="bottom-icon"></div>
          </div>
          <div class="skills-data hidden">
            <!-- ======= Skills Section ======= -->
            <section id="skills" class="skills">
              <div class="container" data-aos="fade-up">
                <div class="row skills-content">
                  <div class="col-lg-6">
                    <?php
                    $first_skill_name = get_field('skills_section')['first_skill_name'];
                    $first_skill_value = get_field('skills_section')['first_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $first_skill_name; ?><i
                          class="val"><?php echo $first_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $first_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $second_skill_name = get_field('skills_section')['second_skill_name'];
                    $second_skill_value = get_field('skills_section')['second_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $second_skill_name; ?><i
                          class="val"><?php echo $second_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $second_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $third_skill_name = get_field('skills_section')['third_skill_name'];
                    $third_skill_value = get_field('skills_section')['third_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $third_skill_name; ?><i
                          class="val"><?php echo $third_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $third_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $fourth_skill_name = get_field('skills_section')['fourth_skill_name'];
                    $fourth_skill_value = get_field('skills_section')['fourth_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $fourth_skill_name; ?><i
                          class="val"><?php echo $fourth_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $fourth_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $fifth_skill_name = get_field('skills_section')['fifth_skill_name'];
                    $fifth_skill_value = get_field('skills_section')['fifth_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $fifth_skill_name; ?><i
                          class="val"><?php echo $fifth_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $fifth_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <?php
                    $sixth_skill_name = get_field('skills_section')['sixth_skill_name'];
                    $sixth_skill_value = get_field('skills_section')['sixth_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $sixth_skill_name; ?><i
                          class="val"><?php echo $sixth_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $sixth_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $seventh_skill_name = get_field('skills_section')['seventh_skill_name'];
                    $seventh_skill_value = get_field('skills_section')['seventh_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $seventh_skill_name; ?><i
                          class="val"><?php echo $seventh_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $seventh_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $eighth_skill_name = get_field('skills_section')['eighth_skill_name'];
                    $eighth_skill_value = get_field('skills_section')['eighth_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $eighth_skill_name; ?><i
                          class="val"><?php echo $eighth_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $eighth_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $ninth_skill_name = get_field('skills_section')['ninth_skill_name'];
                    $ninth_skill_value = get_field('skills_section')['ninth_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $ninth_skill_name; ?><i
                          class="val"><?php echo $ninth_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $ninth_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                    <?php
                    $tenth_skill_name = get_field('skills_section')['tenth_skill_name'];
                    $tenth_skill_value = get_field('skills_section')['tenth_skill_value'];
                    ?>
                    <div class="progress">
                      <span class="skill"><?php echo $tenth_skill_name; ?><i
                          class="val"><?php echo $tenth_skill_value; ?></i></span>
                      <div class="progress-bar-wrap">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $tenth_skill_value; ?>"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section><!-- End Skills Section -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Resume Section -->
  <!-- ======= Counts Section ======= -->
  <section id="counts" class="counts">
    <div class="container" data-aos="fade-up">
      <div class="row">
        <?php
        $counter_section_heading = get_field('counter_section')['section_heading'];
        if ($counter_section_heading) {
          echo '<h2>' . esc_html($counter_section_heading) . '</h2>';
        } else {
          echo '<h2>Why You Should Hire Me</h2>';
        }
        ?>
        <div class="col-lg-3 col-md-6">
          <?php
          $first_counter_number_range = get_field('counter_section')['first_counter_number_range'];
          $first_counter_heading = get_field('counter_section')['first_counter_heading'];
          if ($first_counter_number_range && $first_counter_heading) {
            echo '<div class="count-box">';
            echo '<i class="bi bi-emoji-smile"></i>';
            echo '<span data-purecounter-start="0" data-purecounter-end="' . esc_attr($first_counter_number_range) . '" data-purecounter-duration="1" class="purecounter"></span>';
            echo '<p>' . esc_html($first_counter_heading) . '</p>';
            echo '</div>';
          }
          ?>
        </div>
        <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
          <?php
          $second_counter_number_range = get_field('counter_section')['second_counter_number_range'];
          $second_counter_heading = get_field('counter_section')['second_counter_heading'];
          if ($second_counter_number_range && $second_counter_heading) {
            echo '<div class="count-box">';
            echo '<i class="bi bi-check-circle"></i>';
            echo '<span data-purecounter-start="0" data-purecounter-end="' . esc_attr($second_counter_number_range) . '" data-purecounter-duration="1" class="purecounter"></span>';
            echo '<p>' . esc_html($second_counter_heading) . '</p>';
            echo '</div>';
          }
          ?>
        </div>
        <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
          <?php
          $third_counter_number_range = get_field('counter_section')['third_counter_number_range'];
          $third_counter_heading = get_field('counter_section')['third_counter_heading'];
          if ($third_counter_number_range && $third_counter_heading) {
            echo '<div class="count-box">';
            echo '<i class="bi bi-award"></i>';
            echo '<span data-purecounter-start="0" data-purecounter-end="' . esc_attr($third_counter_number_range) . '" data-purecounter-duration="1" class="purecounter"></span>';
            echo '<p>' . esc_html($third_counter_heading) . '</p>';
            echo '</div>';
          }
          ?>
        </div>
        <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
          <?php
          $fourth_counter_number_range = get_field('counter_section')['fourth_counter_number_range'];
          $fourth_counter_heading = get_field('counter_section')['fourth_counter_heading'];
          if ($fourth_counter_number_range && $fourth_counter_heading) {
            echo '<div class="count-box">';
            echo '<i class="bi bi-calendar-week"></i>';
            echo '<span data-purecounter-start="0" data-purecounter-end="' . esc_attr($fourth_counter_number_range) . '" data-purecounter-duration="1" class="purecounter"></span>';
            echo '<p>' . esc_html($fourth_counter_heading) . '</p>';
            echo '</div>';
          }
          ?>
        </div>
      </div>
    </div>
  </section><!-- End Counts Section -->
  <!-- ======= Contact Section ======= -->
  <section id="contact" class="contact">
    <div class="container" data-aos="fade-up">
      <div class="row footer-form">
        <div class="col-lg-8 col-md-6 col-sm-12 form">
          <h2> Contact Me</h2>
          <h6> I am available for freelancing</h6>
          <?php
          $contact_form_shortcode = get_field('contact_section')['from_shortcode'];
          if ($contact_form_shortcode) {
            echo do_shortcode($contact_form_shortcode);
          } else {
            echo do_shortcode('[contact-form-7 id="c2cbc17" title="Contact form 1"]');
          }
          ?>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 contact-links">
          <div class="phone" data-aos="fade-up">
            <img src="<?php echo get_template_directory_uri() . '/assets/img/phone.png'; ?>" alt="">
            <h3> Phone Number</h3>
            <?php
            $phone_number = get_field('contact_section')['phone_number'];
            $phone_link = get_field('contact_section')['phone_link'];
            ?>
            <a href="tel:<?php echo esc_html($phone); ?>"><?php echo esc_html($phone_number); ?></a>
          </div>
          <div class="email" data-aos="fade-up">
            <img src="<?php echo get_template_directory_uri() . '/assets/img/email.png'; ?>" alt="">
            <h3> Email Address</h3>
            <?php
            $email = get_field('contact_section')['email'];
            $email_link = get_field('contact_section')['email_link'];
            ?>
            <a href="mailto:<?php echo esc_html($email); ?>"><?php echo esc_html($email); ?></a>
          </div>
          <div class="location" data-aos="fade-up">
            <img src="<?php echo get_template_directory_uri() . '/assets/img/location.png'; ?>" alt="">
            <h3>Location</h3>
            <?php $location = get_field('contact_section')['location']; ?>
            <a href="#"><?php echo $location ?></a>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End Contact Section -->
</main><!-- End #main -->
<?php
get_footer();
?>