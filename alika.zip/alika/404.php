<?php
// This file is used for 404 page
get_header();
?>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        color: #333;
    }

    .main-404 {
        text-align: center;
        margin-top: 100px;
    }

    .main-404 h2 {
        font-size: 36px;
    }

    .search-form {
        margin-top: 20px;
        text-align: center;
    }

    .search-form input[type="text"] {
        padding: 10px;
        width: 300px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }

    .search-form input[type="submit"] {
        padding: 10px 20px;
        background-color: #487cb9;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .search-form input[type="submit"]:hover {
        background-color: #487cb9;
    }
</style>
<div class="main-404">
    <h2>404</h2>
    <h3>Page Not Found</h3>
    <div class="search-form">
        <form action="<?php echo esc_url(home_url('/')); ?>" method="get">
            <input type="text" name="s" placeholder="Search..." value="<?php echo get_search_query(); ?>">
            <input type="submit" value="Search">
        </form>
    </div>
</div>

<?php
get_footer();
?>