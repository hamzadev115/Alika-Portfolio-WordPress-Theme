<?php
// This file is used for search results
get_header(); ?>

<div class="main-content">
    <div class="container">
        <h2>Search Results</h2>
        <?php if (have_posts()): ?>
            <ul>
                <?php while (have_posts()):
                    the_post(); ?>
                    <li>
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </li>
                <?php endwhile; ?>
            </ul>
            <?php the_posts_pagination(); ?>
        <?php else: ?>
            <p>No results found for "<?php echo esc_html(get_search_query()); ?>".</p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>