<?php
/**
 * Alika Theme Customizer
 * @package Alika
 */
/**
 * Add postMessage support for site title and description for the Theme Customizer.
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function alika_customize_register($wp_customize)
{
	$wp_customize->get_setting('blogname')->transport = 'postMessage';
	$wp_customize->get_setting('blogdescription')->transport = 'postMessage';
	$wp_customize->get_setting('header_textcolor')->transport = 'postMessage';

	if (isset($wp_customize->selective_refresh)) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector' => '.site-title a',
				'render_callback' => 'alika_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector' => '.site-description',
				'render_callback' => 'alika_customize_partial_blogdescription',
			)
		);
	}
}
add_action('customize_register', 'alika_customize_register');
/**
 * Render the site title for the selective refresh partial.
 * @return void
 */
function alika_customize_partial_blogname()
{
	bloginfo('name');
}
/**
 * Render the site tagline for the selective refresh partial.
 * @return void
 */
function alika_customize_partial_blogdescription()
{
	bloginfo('description');
}

function alika_customize_preview_js()
{
	wp_enqueue_script('alika-customizer', get_template_directory_uri() . '/assets/js/customizer.js', array('customize-preview'), '1.0', true);
}
add_action('customize_preview_init', 'alika_customize_preview_js');


// Customizer
function custom_theme_customizer_settings($wp_customize)
{
	// Copyright Section
	$wp_customize->add_section(
		'copyright_section',
		array(
			'title' => __('Copyright', 'alika'),
			'priority' => 70,
		)
	);
	$wp_customize->add_setting(
		'copyright_setting',
		array(
			'default' => 'Copyright © 2024 Alika',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'copyright_control',
		array(
			'type' => 'text',
			'label' => __('Copyright Text', 'alika'),
			'section' => 'copyright_section',
			'settings' => 'copyright_setting',
		)
	);
	// Footer Logo Section
	$wp_customize->add_section(
		'footer_logo_section',
		array(
			'title' => __('Footer Logo', 'alika'),
			'priority' => 50,
		)
	);
	$wp_customize->add_setting(
		'footer_logo_setting',
		array(
			'default' => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'footer_logo_control',
			array(
				'label' => __('Footer Logo', 'alika'),
				'section' => 'footer_logo_section',
				'settings' => 'footer_logo_setting',
			)
		)
	);
}
add_action('customize_register', 'custom_theme_customizer_settings');

function my_theme_kirki_customizer_setup() {
	if ( class_exists( 'Kirki' ) ) {
		function kirki_header_customizer() {
		  new \Kirki\Panel(
			'header_settings',
			[
			  'priority' => 50,
			  'title' => esc_html__('Header Settings', 'kirki'),
			]
		  );
		  new \Kirki\Section(
			'header_icon',
			[
			  'title' => esc_html__('Social Links', 'kirki'),
			  'panel' => 'header_settings',
			  'priority' => 60,
			]
		  );
		  new \Kirki\Field\URL(
			[
			  'settings' => 'fb_url_setting',
			  'label' => esc_html__('Facebook Url', 'kirki'),
			  'section' => 'header_icon',
			  'default' => '',
			  'priority' => 10,
			]
		  );
		  new \Kirki\Field\URL(
			[
			  'settings' => 'instagram_url_setting',
			  'label' => esc_html__('Instagram Url', 'kirki'),
			  'section' => 'header_icon',
			  'default' => '',
			  'priority' => 20,
			]
		  );
		  new \Kirki\Field\URL(
			[
			  'settings' => 'linkedin_url_setting',
			  'label' => esc_html__('Linkedin Url', 'kirki'),
			  'section' => 'header_icon',
			  'default' => '',
			  'priority' => 30,
			]
		  );
		  new \Kirki\Field\URL(
			[
			  'settings' => 'twitter_url_setting',
			  'label' => esc_html__('Twitter', 'kirki'),
			  'section' => 'header_icon',
			  'default' => '',
			  'priority' => 40,
			]
		  );
		  // Button Section
		  new \Kirki\Section(
			'header_button',
			[
			  'title' => esc_html__('Header Button', 'kirki'),
			  'panel' => 'header_settings',
			  'priority' => 70,
			]
		  );
		  new \Kirki\Field\Text(
			[
			  'settings' => 'button_text_setting',
			  'label' => esc_html__('Button Text', 'kirki'),
			  'section' => 'header_button',
			  'default' => '',
			  'priority' => 10,
			]
		  );
		  new \Kirki\Field\URL(
			[
			  'settings' => 'button_link_setting',
			  'label' => esc_html__('Button Link', 'kirki'),
			  'section' => 'header_button',
			  'default' => '',
			  'priority' => 20,
			]
		  );
		  // Theme Settings Panel
		  new \Kirki\Panel(
			'theme_settings',
			[
			  'priority' => 20,
			  'title' => esc_html__('Theme Settings', 'kirki'),
			]
		  );
		  new \Kirki\Section(
			'general_settings',
			[
			  'title' => esc_html__('General Settings', 'kirki'),
			  'panel' => 'theme_settings',
			  'priority' => 10,
			]
		  );
		  // Color Settings Section
		  new \Kirki\Section(
			'color_settings',
			[
			  'title' => esc_html__('Color Settings', 'kirki'),
			  'panel' => 'theme_settings',
			  'priority' => 20,
			]
		  );
		  new \Kirki\Field\Color(
			[
			  'settings' => 'primary_color_setting',
			  'label' => esc_html__('Primary Color', 'kirki'),
			  'section' => 'color_settings',
			  'default' => '#487CB9',
			  'priority' => 20,
		
			]
		  );
		
		  new \Kirki\Field\Color(
			[
			  'settings' => 'secondary_color_setting',
			  'label' => esc_html__('Secondary Color', 'kirki'),
			  'section' => 'color_settings',
			  'default' => '#F1F6FC',
			  'priority' => 30,
			]
		  );
		  new \Kirki\Field\Color(
			[
			  'settings' => 'white_background_color_setting',
			  'label' => esc_html__('White Color', 'kirki'),
			  'section' => 'color_settings',
			  'default' => '#ffffff',
			  'priority' => 50,
			]
		  );
		  new \Kirki\Field\Color(
			[
			  'settings' => 'body_background_color_setting',
			  'label' => esc_html__('Body Background Color', 'kirki'),
			  'section' => 'color_settings',
			  'default' => '#ffffff',
			  'priority' => 50,
			]
		  );
		  new \Kirki\Field\Color(
			[
			  'settings' => 'text_color_setting',
			  'label' => esc_html__('Text Color', 'kirki'),
			  'section' => 'color_settings',
			  'default' => '#2c2c2c',
			  'priority' => 70,
			]
		  );
		  // Font Settings Section
		  new \Kirki\Section(
			'font_settings',
			[
			  'title' => esc_html__('Font Settings', 'kirki'),
			  'panel' => 'theme_settings',
			  'priority' => 30,
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'heading_1_setting',
			  'label' => esc_html__('Heading 1 Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 10,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'bold',
				'font-style' => 'normal',
				'color' => '#333333',
				'font-size' => '57px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'h1',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'heading_2_setting',
			  'label' => esc_html__('Heading 2 Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 20,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'bold',
				'font-style' => 'normal',
				'font-size' => '48px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'h2',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'heading_3_setting',
			  'label' => esc_html__('Heading 3 Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 30,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'medium',
				'font-style' => 'normal',
				'font-size' => '27px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'h3',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'heading_4_setting',
			  'label' => esc_html__('Heading 4 Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 40,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'medium',
				'font-style' => 'normal',
				'font-size' => '25px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'h4',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'heading_5_setting',
			  'label' => esc_html__('Heading 5 Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 50,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'bold',
				'font-style' => 'normal',
				'font-size' => '20px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'h5',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'heading_6_setting',
			  'label' => esc_html__('Heading 6 Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 60,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'regular',
				'font-style' => 'normal',
				'font-size' => '18px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'h6',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'link_setting',
			  'label' => esc_html__('Link Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 70,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'regular',
				'font-style' => 'normal',
				'font-size' => '16px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'a',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'text_setting',
			  'label' => esc_html__('Text Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 80,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'regular',
				'font-style' => 'normal',
				'font-size' => '16px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'p',
				],
			  ],
			]
		  );
		  new \Kirki\Field\Typography(
			[
			  'settings' => 'text_setting',
			  'label' => esc_html__('Text Settings', 'kirki'),
			  'section' => 'font_settings',
			  'priority' => 80,
			  'transport' => 'auto',
			  'default' => [
				'font-family' => 'Poppins',
				'variant' => 'regular',
				'font-style' => 'normal',
				'font-size' => '16px',
				'line-height' => '1.5',
				'letter-spacing' => '0',
				'text-transform' => 'none',
				'text-decoration' => 'none',
			  ],
			  'output' => [
				[
				  'element' => 'td',
				],
			  ],
			]
		  );
		}
		kirki_header_customizer();
	}
  }
  add_action( 'after_setup_theme', 'my_theme_kirki_customizer_setup' );