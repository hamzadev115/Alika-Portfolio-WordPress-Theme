<?php
/**
 * The template for displaying a single post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Alika
 */

get_header();
?>
<style>
    .site-main {
        margin-top: 70px;
        margin-bottom: 70px;
    }
</style>
<div id="primary" class="content-area">
    <main id="main" class="site-main container">
        <?php
        while (have_posts()):
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
                </header>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </article>

            <?php
            // If comments are open or if we have at least one comment, load the comment template
            if (comments_open() || get_comments_number()):
                comments_template();
            endif;
        endwhile;
        ?>
    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
?>