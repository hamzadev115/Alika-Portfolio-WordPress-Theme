<?php
get_header();
?>
<style>
    #main-index {
        margin-top: 70px;
        margin-bottom: 70px;
    }

    .entry-meta {
        margin-bottom: 10px;
    }

    .entry-content {
        margin: 20px 0px;
    }

    .post-thumbnail a img {
        width: 100%;
        height: auto;
    }
</style>
<div class="container" id="main-index">
    <?php if (have_posts()):
        while (have_posts()):
            the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <h2 class="entry-title">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
                    </h2>
                    <div class="entry-meta">
                        <span class="author"><?php the_author(); ?>,</span>
                        <span class="date"><?php the_date(); ?>,</span>
                        <span class="comments"><?php comments_number(); ?></span>
                    </div>
                    <?php if (has_post_thumbnail()): ?>
                        <div class="post-thumbnail">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                <?php the_post_thumbnail('medium'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </header>
                <div class="entry-content">
                    <?php the_excerpt(); ?>
                </div>
            </article>
        <?php endwhile;
    else: ?>
        <p>Sorry, no posts matched your criteria.</p>
    <?php endif; ?>
</div>

<?php
get_footer();
?>