<?php
/**
 * Enqueue scripts and styles.
 */
function alika_setup()
{
  add_theme_support('automatic-feed-links');
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  register_nav_menus(
    array(
      'menu-1' => esc_html__('Primary', 'alika'),
      'menu-2' => esc_html__('Services Menu', 'alika'),
      'menu-3' => esc_html__('Footer Menu', 'alika'),
    )
  );
  add_theme_support(
    'html5',
    array(
      'search-form',
      'comment-form',
      'comment-list',
      'gallery',
      'caption',
      'style',
      'script',
    )
  );
  add_theme_support('customize-selective-refresh-widgets');

}
add_action('after_setup_theme', 'alika_setup');
function alika_custom_logo_setup()
{
  $defaults = array(
    'flex-height' => true,
    'flex-width' => true,
    'header-text' => array('site-title', 'site-description'),
    'unlink-homepage-logo' => true,
  );

  add_theme_support('custom-logo', $defaults);
}

add_action('after_setup_theme', 'alika_custom_logo_setup');
function alika_content_width()
{
  $GLOBALS['content_width'] = apply_filters('alika_content_width', 640);
}
add_action('after_setup_theme', 'alika_content_width', 0);
function alika_widgets_init()
{
  register_sidebar(
    array(
      'name' => esc_html__('Sidebar', 'alika'),
      'id' => 'sidebar-1',
      'description' => esc_html__('Add widgets here.', 'alika'),
      'before_widget' => '<section id="%1$s" class="widget %2$s">',
      'after_widget' => '</section>',
      'before_title' => '<h2 class="widget-title">',
      'after_title' => '</h2>',
    )
  );
}
add_action('widgets_init', 'alika_widgets_init');
/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * TGM Plugin Activation
 */
require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/install-plugin.php';
/**
 * Enqueue Post Types
 */
require get_template_directory() . '/inc/post-types/home-group.php';
require get_template_directory() . '/inc/post-types/portfolio-posttype.php';



function alika_theme_scripts()
{
  wp_enqueue_style('magnific-popup', 'https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css');
  wp_enqueue_style('bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css');
  wp_enqueue_style('aos-css', 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css');
  wp_enqueue_style('glightbox-css', 'https://cdnjs.cloudflare.com/ajax/libs/glightbox/3.2.0/css/glightbox.min.css');
  wp_enqueue_style('swiper-css', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/9.0.5/swiper-bundle.css');
  wp_enqueue_style('bootstrap-icons', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.3/font/bootstrap-icons.min.css');
  wp_enqueue_style('boxicons', 'https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.4/css/boxicons.min.css');
  wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css');
  wp_enqueue_style('fontawesome-v4', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/v4-shims.min.css');
  wp_enqueue_style('owl-carousel-style', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css');
  wp_enqueue_style('style', get_stylesheet_uri());
  // Enqueue my scripts.
  wp_enqueue_script('magnific-popup', 'https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js', array('jquery'), '', true);
  wp_enqueue_script('fontawesome-js', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js', array('jquery'), null, true);
  wp_enqueue_script('fontawesome-js-v4', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/v4-shims.min.js', array('jquery'), null, true);
  wp_enqueue_script('owl-carousel-script', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js', array('jquery'), null, true);
  wp_enqueue_script('aos-js', 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js', array('jquery'), null, true);
  wp_enqueue_script('purecounter-script', 'https://cdn.jsdelivr.net/npm/@srexi/purecounterjs@1.5.0/dist/purecounter_vanilla.min.js', array('jquery'), null, true);
  wp_enqueue_script('glightbox-script', 'https://cdnjs.cloudflare.com/ajax/libs/glightbox/3.2.0/js/glightbox.min.js', array('jquery'), null, true);
  wp_enqueue_script('swiper-script', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/9.0.5/swiper-bundle.min.js', array('jquery'), null, true);
  wp_enqueue_script('isotope-script', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js', array('jquery'), null, true);
  wp_enqueue_script('waypoints-script', 'https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/noframework.waypoints.min.js', array('jquery'), null, true);
  wp_enqueue_script('jquery');
  wp_enqueue_script('bootstrap-js', '//cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js', array('jquery'), false);
  wp_enqueue_script('alika-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), null, true);
  if (is_singular() && comments_open() && get_option('thread_comments')) {
    wp_enqueue_script('comment-reply');
  }
}
add_action('wp_enqueue_scripts', 'alika_theme_scripts');


// AJAX handler for loading more portfolio items
add_action('wp_ajax_load_more_portfolio', 'load_more_portfolio');
add_action('wp_ajax_nopriv_load_more_portfolio', 'load_more_portfolio');

function load_more_portfolio()
{
  $offset = $_POST['offset'];
  $posts_per_page = $_POST['posts_per_page'];

  $args = array(
    'post_type' => 'project',
    'posts_per_page' => $posts_per_page,
    'offset' => $offset
  );

  $query = new WP_Query($args);
  if ($query->have_posts()) {
    while ($query->have_posts()) {
      $query->the_post();
      // Output your portfolio item markup here similar to what's inside the loop in your initial code
      // Remember to increment $counter accordingly
    }
    wp_reset_postdata();
  } else {
    echo 'No more items';
  }

  die(); // Always end with die() in AJAX functions
}
