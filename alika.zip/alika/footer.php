<?php
/**
 * footer.
 */
?>
<!-- ======= Footer ======= -->
<footer id="footer">
  <div class="top-footer">
    <div class="container-fluid">
      <div class="row">
        <div class="footer-logo">
          <?php $footer_logo_url = get_theme_mod('footer_logo_setting'); ?>
          <?php if ($footer_logo_url): ?>
            <img src="<?php echo esc_url($footer_logo_url); ?>" alt="Footer Logo">
          <?php endif; ?>
        </div>
        <div class="footer-menu">
          <div class="container">
            <?php
            wp_nav_menu(
              array(
                'theme_location' => 'menu-3'
              )
            );
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <h2><?php echo esc_html(get_theme_mod('copyright_setting', 'Copyright © 2024 Alika')); ?></h2>
  </div>
</footer><!-- End Footer -->
<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
    class="bi bi-arrow-up-short"></i></a>
<?php wp_footer(); ?>
</div>
</div>
</body>

</html>